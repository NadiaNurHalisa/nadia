/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOmovie_db.movie_dbDAO;
import DAOImplement.movie_dbimplement;
import model.*;
import view.MainView;
/**
 *
 * @author Surya Aji
 */

public class controller {
    MainView frame;
    movie_dbimplement implmovie_db;
    List<movie_db> dp;
    
    public controller(MainView frame){
        this.frame = frame;
        movie_db = new movie_dbDAO();
        dp = implmovie_db.getAll();
    }
    public void isitabel(){
        dp = implmovie_db.getAll();
        modeltabelmovie_db mp = new modeltabelmovie_db(dp);
        frame.getTabelmovie_db().setjudul(mp);
    }
    
    public void insert(){
        movie_db dp = new movie_db();
        dp.setMerk(frame.getJTxtjudul().getText());
        dp.setBrand(frame.getJtxtalur().getText());
        dp.setChip(frame.getJtxtpenokohan().getText());
        dp.setChip(frame.getJtxtakting().getText());
        dp.setChip(frame.getJtxtnilai().getText());
        implmovie_db.insert(dp);
        
    }
    
    public void update(){
        movie_db dp = new movie_db();
        dp.setjudul(frame.getJTxtjudul().getText());
        dp.setalur(frame.getJtxtalur().getText());
        dp.setpenokohan(frame.getJtxtpenokohan().getText());
        dp.setakting(frame.getJtxtakting().getText());
        dp.setnilai(frame.getJtxtnilai().getText());
        dp.setId(Integer.parseInt(frame.getJTxtid().getText()));
        implmovie_db.update(dp);
    }
    
    public void delete(){
        int id = Integer.parseInt(frame.getJTxtid().getText());
        implmovie_db.delete(id);
    }
}
