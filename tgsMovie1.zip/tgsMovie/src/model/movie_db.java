/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Surya Aji
 */
public class movie_db {
    private Integer id;
    private String judul;
    private String alur;
    private String penokohan;
    private String akting;
    private Integer nilai;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getjudul() {
        return judul;
    }

    public void setjudul(String judul) {
        this.judul = judul;
    }

    public String getalur() {
        return alur;
    }

    public void setalur(String alur) {
        this.alur = alur;
    }

    public String getpenokohan() {
        return penokohan;
    }

    public void setpenokohan(String penokohan) {
        this.penokohan = penokohan;
    }
    public String akting() {
        return akting;
    }

    public void setakting(String akting) {
        this.akting = akting;
    }
    
    public Integer getnilai() {
        return nilai;
    }

    public void setnilai(Integer nilai) {
        this.nilai = nilai;
    }
    
    
}
